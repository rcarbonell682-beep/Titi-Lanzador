package mini.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

public class L extends Activity {
    G g;
    final BroadcastReceiver r = new BroadcastReceiver() {
        public void onReceive(Context c, Intent i) {
            g.load();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        g = new G(this);
        setContentView(g);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        registerReceiver(r, f);
        g.load();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        g.home();
    }

    @Override
    public void onBackPressed() {
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(r);
        super.onDestroy();
    }
}
