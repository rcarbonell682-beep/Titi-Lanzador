package mini.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowInsets;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class G extends View {
    static class A {
        String pkg, label, shown;
        ComponentName cn;
        Bitmap ic;
    }

    final PackageManager pm;
    final float d;
    final int is, slop;
    final Paint p = new Paint(Paint.FILTER_BITMAP_FLAG);
    final Paint t = new Paint(Paint.ANTI_ALIAS_FLAG);
    List<A> apps = new ArrayList<>();
    float scroll, x0, y0, lx;
    int w, h, top, bot, cw, ch, rows, ps, pages, n, gy, gen;
    boolean moved, lp;
    ValueAnimator an;
    VelocityTracker vt;

    final Runnable lpr = new Runnable() {
        public void run() {
            A a = hit(x0, y0);
            if (a != null) {
                lp = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                menu(a);
            }
        }
    };

    G(Context c) {
        super(c);
        pm = c.getPackageManager();
        d = c.getResources().getDisplayMetrics().density;
        is = (int) (48 * d);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        t.setColor(Color.WHITE);
        t.setTextSize(12 * d);
        t.setTextAlign(Paint.Align.CENTER);
        t.setShadowLayer(3 * d, 0, d, 0xB0000000);
    }

    void load() {
        final int id = ++gen;
        new Thread(new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> l = pm.queryIntentActivities(i, 0);
                final ArrayList<A> o = new ArrayList<>();
                String me = getContext().getPackageName();
                for (ResolveInfo r : l) {
                    if (r.activityInfo.packageName.equals(me)) continue;
                    A a = new A();
                    a.pkg = r.activityInfo.packageName;
                    a.cn = new ComponentName(a.pkg, r.activityInfo.name);
                    a.label = String.valueOf(r.loadLabel(pm));
                    Drawable dr = r.loadIcon(pm);
                    Bitmap b = Bitmap.createBitmap(is, is, Bitmap.Config.ARGB_8888);
                    dr.setBounds(0, 0, is, is);
                    dr.draw(new Canvas(b));
                    a.ic = b;
                    o.add(a);
                }
                Collections.sort(o, new java.util.Comparator<A>() {
                    public int compare(A x, A y) {
                        return x.label.compareToIgnoreCase(y.label);
                    }
                });
                post(new Runnable() {
                    public void run() {
                        if (id != gen) return;
                        apps = o;
                        grid();
                    }
                });
            }
        }).start();
    }

    void grid() {
        n = apps.size();
        if (w == 0 || n == 0) {
            pages = 0;
            invalidate();
            return;
        }
        cw = w / 4;
        ch = (int) (78 * d);
        int av = h - top - bot - (int) (24 * d);
        rows = Math.max(1, av / ch);
        ps = rows * 4;
        pages = (n + ps - 1) / ps;
        gy = top + (int) (12 * d) + Math.max(0, (av - rows * ch) / 2);
        float mw = cw - 8 * d;
        for (A a : apps) a.shown = TextUtils.ellipsize(a.label, t, mw, TextUtils.TruncateAt.END).toString();
        float tot = (float) pages * w;
        scroll = ((scroll % tot) + tot) % tot;
        if (pages == 1) scroll = 0;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int nw, int nh, int ow, int oh) {
        w = nw;
        h = nh;
        grid();
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets i) {
        top = i.getSystemWindowInsetTop();
        bot = i.getSystemWindowInsetBottom();
        grid();
        return i;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (pages == 0) return;
        int base = (int) Math.floor(scroll / w);
        for (int k = base; k <= base + 1; k++) {
            float ox = k * (float) w - scroll;
            if (ox >= w || ox <= -w) continue;
            int pg = Math.floorMod(k, pages);
            for (int i = 0; i < ps; i++) {
                int idx = pg * ps + i;
                if (idx >= n) break;
                A a = apps.get(idx);
                float cx = ox + (i % 4) * cw + cw / 2f;
                float y = gy + (i / 4) * ch;
                c.drawBitmap(a.ic, cx - is / 2f, y, p);
                c.drawText(a.shown, cx, y + is + 18 * d, t);
            }
        }
    }

    A hit(float x, float y) {
        if (pages == 0 || y < gy) return null;
        float sx = x + scroll;
        int k = (int) Math.floor(sx / w);
        int col = Math.min(3, (int) ((sx - k * (float) w) * 4 / w));
        int row = (int) ((y - gy) / ch);
        if (row >= rows) return null;
        int idx = Math.floorMod(k, pages) * ps + row * 4 + col;
        return idx < n ? apps.get(idx) : null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (an != null) an.cancel();
                x0 = lx = e.getX();
                y0 = e.getY();
                moved = false;
                lp = false;
                if (vt != null) vt.recycle();
                vt = VelocityTracker.obtain();
                vt.addMovement(e);
                postDelayed(lpr, ViewConfiguration.getLongPressTimeout());
                return true;
            case MotionEvent.ACTION_MOVE:
                if (vt == null) return true;
                vt.addMovement(e);
                if (!moved && Math.hypot(e.getX() - x0, e.getY() - y0) > slop) {
                    moved = true;
                    removeCallbacks(lpr);
                    lx = e.getX();
                }
                if (moved && pages > 1) {
                    scroll -= e.getX() - lx;
                    lx = e.getX();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                removeCallbacks(lpr);
                if (vt != null) {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    float vx = vt.getXVelocity();
                    vt.recycle();
                    vt = null;
                    if (moved) {
                        if (pages > 1) snap(vx);
                    } else if (!lp) {
                        A a = hit(e.getX(), e.getY());
                        if (a != null) open(a);
                    }
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(lpr);
                if (vt != null) {
                    vt.recycle();
                    vt = null;
                }
                if (moved && pages > 1) snap(0);
                return true;
        }
        return true;
    }

    void snap(float vx) {
        float cur = scroll / w;
        int tg;
        if (vx < -600) tg = (int) Math.floor(cur) + 1;
        else if (vx > 600) tg = (int) Math.ceil(cur) - 1;
        else tg = Math.round(cur);
        animTo(tg * (float) w);
    }

    void animTo(float to) {
        if (an != null) an.cancel();
        an = ValueAnimator.ofFloat(scroll, to);
        an.setDuration(220);
        an.setInterpolator(new DecelerateInterpolator());
        an.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator v) {
                scroll = (Float) v.getAnimatedValue();
                invalidate();
            }
        });
        an.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator a) {
                if (pages > 0) {
                    float tot = (float) pages * w;
                    scroll = ((scroll % tot) + tot) % tot;
                }
            }
        });
        an.start();
    }

    void home() {
        if (pages < 2) return;
        float tot = (float) pages * w;
        animTo(Math.round(scroll / tot) * tot);
    }

    void open(A a) {
        try {
            getContext().startActivity(new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(a.cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED));
        } catch (Exception x) {
        }
    }

    void menu(final A a) {
        new AlertDialog.Builder(getContext())
                .setTitle(a.label)
                .setItems(new String[]{"Información", "Desinstalar"}, new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface dg, int i) {
                        Intent in = new Intent(i == 0 ? Settings.ACTION_APPLICATION_DETAILS_SETTINGS : Intent.ACTION_DELETE);
                        in.setData(Uri.parse("package:" + a.pkg));
                        try {
                            getContext().startActivity(in);
                        } catch (Exception x) {
                        }
                    }
                })
                .show();
    }
}
